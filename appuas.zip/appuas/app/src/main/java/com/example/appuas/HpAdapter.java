package com.example.appuas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class HpAdapter extends RecyclerView.Adapter<HpAdapter.HpViewHolder> { 
    public Context context;
    public ArrayList<handphone> handphones;

    public HpAdapter(Context mcontext, ArrayList<handphone> daftarhp){
        context=mcontext;
        handphones=daftarhp;
    }

    @NonNull
    @Override
    public HpViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View v = LayoutInflater.from(context).inflate(R.layout.itemhp,parent,false);
        return new HpViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HpViewHolder holder, int position) {
        final handphone hpbaru=handphones.get(position);
        String namabaru=hpbaru.getNama();
        String gambarbaru=hpbaru.getGambar();
        String deskripsi=hpbaru.getDeskripsi();

        holder.tvnamadata.setText(namabaru);
        holder.tvdeskripsidata.setText(deskripsi);

        Glide
                .with(context)
                .load(gambarbaru)
                .centerCrop()
                .into(holder.imdata);

        holder.btndes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(v.getContext(),DetailActivity.class);
                pindah.putExtra("nama",hpbaru.getNama());
                pindah.putExtra("deskripsi",hpbaru.getDeskripsi());
                pindah.putExtra("gambar" ,hpbaru.getGambar());
                v.getContext().startActivity(pindah);
            }
        });
    }

    @Override
    public int getItemCount() {
        return handphones.size();
    }

    public class HpViewHolder extends RecyclerView.ViewHolder {
        public ImageView imdata;
        public TextView tvdeskripsidata;
        public TextView tvnamadata;
        public Button btndes;

        public HpViewHolder(@NonNull View itemView) {
            super(itemView);
            imdata=itemView.findViewById(R.id.Ivgambarhp);
            tvdeskripsidata=itemView.findViewById(R.id.textdeskripsi);
            tvnamadata=itemView.findViewById(R.id.textjudul);
            btndes=itemView.findViewById(R.id.btn_des);
        }
    }
}

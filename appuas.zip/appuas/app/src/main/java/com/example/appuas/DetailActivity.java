package com.example.appuas;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class DetailActivity extends AppCompatActivity {
    public static final String handphone = "hpbaru";
    TextView tvnamahp,tvdeshp;
    ImageView imghape;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        tvnamahp=findViewById(R.id.tvnama);
        tvdeshp=findViewById(R.id.tvdeskripsi);
        tvnamahp.setText(getIntent().getStringExtra("nama"));
        tvdeshp.setText(getIntent().getStringExtra("deskripsi"));
        imghape=findViewById(R.id.imgvHape);
        String url=getIntent().getStringExtra("gambar");
        Glide.with(this)
                .load(url)
                .apply(new RequestOptions())
                .override(500, 500)
                .into(imghape);



    }
}

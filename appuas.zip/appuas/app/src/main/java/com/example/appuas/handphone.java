package com.example.appuas;

public class handphone {

    private  String nama;
    private  String deskripsi;
    private  String gambar;

    public  handphone(String datanama,String datadeskripsi,String datagambar){
        nama=datanama;
        deskripsi=datadeskripsi;
        gambar=datagambar;
    }

    public String getNama() {
        return nama;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getGambar() {
        return gambar;
    }

}
